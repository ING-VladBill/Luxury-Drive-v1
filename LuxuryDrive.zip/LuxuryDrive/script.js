document.querySelectorAll('.reservar-btn').forEach(button => {
  button.addEventListener('click', function (e) {
      const carName = e.target.getAttribute('data-car');
      const carImage = e.target.getAttribute('data-img');
      const carDescription = e.target.getAttribute('data-description');
      
      const carImages = {
          'Toyota Hilux 2020': [
              'imagenes/Hilux 2020/hilux1.jpg',
              'imagenes/Hilux 2020/hilux2.jpg',
              'imagenes/Hilux 2020/hilux3.jpg',
              'imagenes/Hilux 2020/hilux4.jpg',
              'imagenes/Hilux 2020/hilux5.jpg'
          ],
          'Toyota Corolla Xli 2022': [
              'imagenes/Corolla xli/corolla1.jpg',
              'imagenes/Corolla xli/corolla2.jpg',
              'imagenes/Corolla xli/corolla3.jpg',
              'imagenes/Corolla xli/corolla4.jpg',
              'imagenes/Corolla xli/corolla5.jpg',
              'imagenes/Corolla xli/corolla6.jpg'
          ],
          'Glory 580 2023': [
              'imagenes/Glory 580/glory1.jpg',
              'imagenes/Glory 580/glory2.jpg',
              'imagenes/Glory 580/glory3.jpg',
              'imagenes/Glory 580/glory4.jpg'
          ],
          'Kia Picanto Cross': [
              'imagenes/picanto/picanto1.jpg',
              'imagenes/picanto/picanto2.jpg',
              'imagenes/picanto/picanto3.jpg',
              'imagenes/picanto/picanto4.jpg',
              'imagenes/picanto/picanto5.jpg',
          ],
          'Hyndai Staria 2023': [
              'imagenes/Staria/staria1.jpg',
              'imagenes/Staria/staria2.jpg',
              'imagenes/Staria/staria3.jpg',
              'imagenes/Staria/staria4.jpg',
              'imagenes/Staria/staria5.jpg',
          ],
          'Changan Uni-t 2024': [
              'imagenes/Uni-t/unit1.jpg',
              'imagenes/Uni-t/unit2.jpg',
              'imagenes/Uni-t/unit3.jpg',
              'imagenes/Uni-t/unit4.jpg',
              'imagenes/Uni-t/unit5.jpg',
              'imagenes/Uni-t/unit6.jpg',
          ]
      };

      document.getElementById('vehiculoNombre').textContent = carName;


      const carouselImages = document.getElementById('carouselImages');
      carouselImages.innerHTML = '';

    
      const images = carImages[carName] || [carImage];


      images.forEach((img, index) => {
          const div = document.createElement('div');
          div.classList.add('carousel-item');
          if (index === 0) div.classList.add('active');
          div.innerHTML = `<img src="${img}" class="d-block w-100" alt="Imagen del vehículo">`;
          carouselImages.appendChild(div);
      });

      const descriptionList = document.getElementById('vehiculoDescripcion');
      descriptionList.innerHTML = '';

      const descriptionItems = carDescription.split(',');
      descriptionItems.forEach(item => {
          const li = document.createElement('li');
          li.textContent = item.trim();
          descriptionList.appendChild(li);
      });

      const reservarBtn = document.getElementById('reservarVehiculoBtn');
      reservarBtn.classList.remove('d-none');
      reservarBtn.addEventListener('click', function (event) {
          event.preventDefault();

      });
  });
});

document.querySelector('.reserva').addEventListener('click', function () {
    const nombre = document.getElementById('nombre').value;
    const correo = document.getElementById('correo').value;
    const teléfono = document.getElementById('teléfono').value;
    const fechaInicio = document.getElementById('fecha-inicio').value;
    const fechaFin = document.getElementById('fecha-fin').value;
    const today = new Date().toISOString().split('T')[0];

    if (fechaInicio < today || fechaFin < today) {
        alert('Las fechas no pueden ser anteriores a la fecha actual.');
        return;
    }

    if (fechaInicio > fechaFin) {
        alert('La fecha de inicio no puede ser posterior a la fecha de fin.');
        return;
    }
    const nombreRegex = /^[a-zA-Z\s]+$/;
    if (!nombreRegex.test(nombre)) {
        alert('Ingrese un nombre válido')
        return;
    }
    
    const correoRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!correoRegex.test(correo)) {
        alert('Por favor ingresa un correo electrónico válido.');
        return;
    }
        
    const telefonoRegex = /^[0-9]{9}$/;
    if (!telefonoRegex.test(teléfono)) {
      alert('Ingresa un número válido de 9 dígitos')
      return;
    }
    if (!nombre || !correo || !teléfono || !fechaInicio || !fechaFin) {
        alert('Por favor, completa todos los campos del formulario.');
        return;
    }

    alert('¡Agenda exitosa! Nos contactaremos contigo en breve.');
  
  });
  
let reservas = [];


document.getElementById('reservarVehiculoBtn').addEventListener('click', function() {
    document.getElementById('formReservaContainer').style.display = 'block';
    document.getElementById('reservarVehiculoBtn').style.display = 'none'; 
});

document.getElementById('confirmarReserva').addEventListener('click', function () {
    const nombre = document.getElementById('nombreReserva').value;
    const correo = document.getElementById('correoReserva').value;
    const telefono = document.getElementById('telefonoReserva').value;
    const fechaInicio = document.getElementById('fechaInicioReserva').value;
    const fechaFin = document.getElementById('fechaFinReserva').value;
    const today = new Date().toISOString().split('T')[0];

    if (fechaInicio < today || fechaFin < today) {
        alert('Las fechas no pueden ser anteriores a la fecha actual.');
        return;
    }

    if (fechaInicio > fechaFin) {
        alert('La fecha de inicio no puede ser posterior a la fecha de fin.');
        return;
    }
    const nombreRegex = /^[a-zA-Z\s]+$/;
    if (!nombreRegex.test(nombre)) {
        alert('Ingrese un nombre válido')
        return;
    }
    
    const correoRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!correoRegex.test(correo)) {
        alert('Por favor ingresa un correo electrónico válido.');
        return;
    }
        
    if (!nombre || !correo || !telefono || !fechaInicio || !fechaFin) {
        alert('Por favor, completa todos los campos.');
        return;
    }
    const reserva = {
        nombre,
        correo,
        telefono,
        fechaInicio,
        fechaFin
    };

    reservas.push(reserva);
    actualizarCarrito(); 


    const vehiculoModal = bootstrap.Modal.getInstance(document.getElementById('vehiculoModal'));
    vehiculoModal.hide();

    document.getElementById('formReserva').reset();

    alert('Reserva agregada al carrito.');
});

function actualizarCarrito() {
    const carritoMenu = document.getElementById('carritoMenu');
    const numeroReservas = document.getElementById('numeroReservas');
    carritoMenu.innerHTML = '';

    if (reservas.length === 0) {
        carritoMenu.innerHTML = `<li id="carritoVacio">No hay reservas aún.</li>`;
        numeroReservas.innerText = 0;
        return;
    }

    reservas.forEach((reserva, index) => {
        const li = document.createElement('li');
        li.classList.add('d-flex', 'justify-content-between', 'align-items-center');
        li.innerHTML = `
            <span>${reserva.nombre} (${reserva.fechaInicio} - ${reserva.fechaFin})</span>
            <div>
                <button class="btn btn-danger btn-sm" onclick="eliminarReserva(${index})">Eliminar</button>
            </div>
        `;
        carritoMenu.appendChild(li);
    });

    numeroReservas.innerText = reservas.length;
    const pagarButton = document.createElement('button');
    pagarButton.classList.add('btn', 'btn-success', 'w-100', 'mt-3');
    pagarButton.textContent = 'Pagar';
    pagarButton.addEventListener('click', mostrarModalPago);
    carritoMenu.appendChild(pagarButton);
}

function eliminarReserva(index) {
    reservas.splice(index, 1);
    actualizarCarrito();
}


function mostrarModalPago() {
    const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
    paymentModal.show();
}

document.getElementById('paymentForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const cardNumber = document.getElementById('cardNumber').value;
    const expirationDate = document.getElementById('expirationDate').value;
    const cvv = document.getElementById('cvv').value;

    const tarjetaRegex = /^4[0-9]{12}(?:[0-9]{3})?$|^5[1-5][0-9]{14}$|^3[47][0-9]{13}$|^6(?:011|5[0-9]{2})[0-9]{12}$/;
    if (!tarjetaRegex.test(cardNumber)) {
        alert('Por favor, ingresa un número de tarjeta válido (Visa, MasterCard, American Express, Discover).');
        return;
    }

    const expiracionRegex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
    if (!expiracionRegex.test(expirationDate)) {
        alert('Por favor, ingresa una fecha de expiración válida (MM/AA).');
        return;
    }

    const cvvRegex = /^[0-9]{3,4}$/;
    if (!cvvRegex.test(cvv)) {
        alert('El CVV debe ser un número de 3 o 4 dígitos.');
        return;
    }

    if (!cardNumber || !expirationDate || !cvv) {
        alert('Por favor, completa todos los campos de pago.');
        return;
    }

    alert('¡Pago procesado con éxito! Gracias por tu reserva.');

    reservas = [];
    actualizarCarrito();

    const paymentModal = bootstrap.Modal.getInstance(document.getElementById('paymentModal'));
    paymentModal.hide();
})